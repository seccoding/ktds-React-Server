// 커스텀 훅을 만드는 방법 : 함수명이 use 로 시작하면,
// React는 훅으로 판단.

import { useEffect, useState } from "react";

/**
 * API 요청을 보내고 응답을 받아오는 훅
 * @param {*} initialValue 응답 데이터의 기본 값
 * @param {*} fnFetch fetch를 수행하는 함수
 */
export function useFetch(initialValue, fnFetch) {
  const [fetchedResult, setFetchedResult] = useState(initialValue);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState();

  // side effect를 방지하는 hook
  useEffect(() => {
    setIsLoading(true);
    setError(undefined);
    setFetchedResult(initialValue);

    fnFetch() // 요청을 전송
      .then((response) => {
        setIsLoading(false);
        setFetchedResult(response);
      }) // 응답을 성공적으로 받아옴
      .catch((error) => {
        setIsLoading(false);
        setError(error.message || "데이터 처리 실패!");
      }); // 요청이 실패했을 때
  }, [initialValue, fnFetch]);

  return { fetchedResult, setFetchedResult, isLoading, error };
}
