const HOST = "http://localhost:8888";

/**
 * 이메일 중복 검사 Fetch
 */
export async function checkEmail(email) {
  // Fetch요청 보내기
  const response = await fetch(`${HOST}/api/v1/member/available/${email}/`, {
    method: "GET",
  });

  console.log("response", response);

  // 요청 성공했을 때, 응답 데이터 반환.
  if (response.ok) {
    // 요청의 응답 받아오기
    const json = await response.json();
    return json;
  }

  // 요청 실패했을 때, 실패 데이터를 예외에 담아서 반환.
  throw new Error(response.statusText);
}

/**
 * 회원가입
 */
export async function regist(email, name, password) {
  const response = await fetch(`${HOST}/api/v1/member`, {
    method: "POST",
    body: JSON.stringify({ email, name, password }),
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 로그인 토큰 발급
 */
export async function getToken(email, password) {
  const response = await fetch(`${HOST}/api/v1/auth/token`, {
    method: "POST",
    body: JSON.stringify({ email, password }),
    headers: {
      "Content-Type": "application/json",
    },
  });

  const json = await response.json();
  if (response.ok) {
    return json;
  }

  throw new Error(json.message);
}

/**
 * 회원 정보 받아오기
 */
export async function loadMyInfo(token) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const response = await fetch(`${HOST}/api/v1/member`, {
    method: "GET",
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 회원 탈퇴하기
 */
export async function deleteMe(token) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const response = await fetch(`${HOST}/api/v1/member`, {
    method: "DELETE",
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 게시글 목록 조회
 */
export async function loadArticles(token, pageNo = 0, listSize = 10) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const response = await fetch(
    `${HOST}/api/v1/boards?pageNo=${pageNo}&listSize=${listSize}`,
    {
      method: "GET",
      headers: {
        Authorization: token,
      },
    }
  );

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 게시글 작성
 */
export async function writeArticle(token, { subject, content, file }) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const formData = new FormData();
  formData.append("subject", subject);
  formData.append("content", content);
  formData.append("file", file);

  const response = await fetch(`${HOST}/api/v1/boards`, {
    method: "POST",
    body: formData,
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 게시글 조회
 */
export async function loadArticleById(token, id) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  if (!id) {
    throw new Error("잘못된 요청입니다.");
  }

  const response = await fetch(`${HOST}/api/v1/boards/${id}`, {
    method: "GET",
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 게시글 수정
 */
export async function modifyArticle(token, { id, subject, content, file }) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const formData = new FormData();
  formData.append("subject", subject);
  formData.append("content", content);
  formData.append("file", file);

  const response = await fetch(`${HOST}/api/v1/boards/${id}`, {
    method: "PUT",
    body: formData,
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 게시글 삭제
 */
export async function deleteArticle(token, id) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const response = await fetch(`${HOST}/api/v1/boards/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const json = await response.json();
    return json;
  }

  throw new Error(response.statusText);
}

/**
 * 첨부파일 다운로드
 */
export async function download({ token, id, fileName }) {
  if (!token) {
    throw new Error("로그인이 필요합니다.");
  }

  const response = await fetch(`${HOST}/api/v1/boards/files/${id}`, {
    method: "GET",
    headers: {
      Authorization: token,
    },
  });

  if (response.ok) {
    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(new Blob([blob]));

    const link = document.createElement("a");
    link.href = blobUrl;
    link.setAttribute("download", `${fileName}`);

    document.body.appendChild(link);
    link.click();
    link.parentNode.removeChild(link);
  }

  throw new Error(response.statusText);
}
