import { useCallback, useRef, useState } from "react";
import { Button, ButtonArea } from "./ui/Input.js";
import Table from "./ui/Table.js";
import { WriteModal } from "./modal/WriteModal.js";
import { ViewModal } from "./modal/ViewModal.js";
import { loadArticles } from "../http/http.js";
import { useFetch } from "../hooks/useFetch.js";

let pageNo = 0;

export default function Main({ token }) {
  const [selectedItemId, setSelectedItemId] = useState();
  const [needReload, setNeedReload] = useState();

  const cachedLoadArticles = useCallback(() => {
    pageNo = 0;
    return loadArticles(token);
  }, [token, needReload]);

  const { fetchedResult, setFetchedResult, isLoading, error } = useFetch(
    undefined,
    cachedLoadArticles
  );

  const writeRef = useRef();
  const viewRef = useRef();

  const onClickWriteHandler = () => {
    writeRef.current.open();
  };

  const onClickViewHandler = (id) => {
    setSelectedItemId(id);
    viewRef.current.open();
  };

  const onClickLoadMoreHandler = () => {
    console.log("!");
    loadArticles(token, ++pageNo).then((response) => {
      setFetchedResult((prevArticles) => {
        return {
          next: response.next,
          body: [...prevArticles.body, ...response.body],
        };
      });
    });
  };

  return (
    <main>
      {error && <div>{error}</div>}
      <div className="right-align">
        총 {fetchedResult ? fetchedResult.count : 0}건의 게시글이
        조회되었습니다.
      </div>
      <Table>
        <Table.Colgroup cols={["80px", "*", "150px", "80px", "150px"]} />
        <Table.Header>
          <tr>
            <th>ID</th>
            <th>Subject</th>
            <th>Author</th>
            <th>View</th>
            <th>Create Date</th>
          </tr>
        </Table.Header>
        <Table.Body>
          {!isLoading &&
            fetchedResult &&
            fetchedResult.body.map(
              ({ id, subject, email, viewCnt, crtDt, memberVO: { name } }) => (
                <tr
                  key={`${id}_${subject}`}
                  onClick={() => onClickViewHandler(id)}
                >
                  <td>{id}</td>
                  <td>{subject}</td>
                  <td title={email}>{name}</td>
                  <td>{viewCnt}</td>
                  <td>{crtDt}</td>
                </tr>
              )
            )}
        </Table.Body>
      </Table>
      <ButtonArea>
        {fetchedResult && fetchedResult.next && (
          <Button onClick={onClickLoadMoreHandler}>더보기</Button>
        )}
        <Button onClick={onClickWriteHandler}>등록</Button>
      </ButtonArea>

      <WriteModal ref={writeRef} token={token} needReloadList={setNeedReload} />
      <ViewModal
        ref={viewRef}
        token={token}
        selectedId={selectedItemId}
        needReloadList={setNeedReload}
      />
    </main>
  );
}
