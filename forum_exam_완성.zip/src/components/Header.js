import { useCallback, useMemo, useRef } from "react";
import { LoginMemberModal } from "./modal/LoginMemberModal.js";
import { RegistMemberModal } from "./modal/RegistMemberModal.js";
import { loadMyInfo } from "../http/http.js";
import { useFetch } from "../hooks/useFetch.js";

export default function Header({ token, setToken }) {
  const loginModalRef = useRef();
  const registModalRef = useRef();

  const onClickLoginHandler = () => {
    loginModalRef.current.open();
  };

  const onClickRegistHandler = () => {
    registModalRef.current.open();
  };

  const onClickLogoutHandler = () => {
    sessionStorage.removeItem("token");
    setToken(undefined);
  };

  const initialValue = useMemo(() => {
    return { body: {} };
  }, []);
  const cachedLoadMyInfo = useCallback(() => loadMyInfo(token), [token]);
  const {
    fetchedResult: myInfo,
    isLoading,
    error,
  } = useFetch(initialValue, cachedLoadMyInfo);
  return (
    <>
      <header>
        <nav>
          <ul>
            {!token && (
              <>
                <li onClick={onClickLoginHandler}>Login</li>
                <li onClick={onClickRegistHandler}>Regist</li>
              </>
            )}
            {token && (
              <>
                <li onClick={onClickLogoutHandler}>Logout</li>
                {isLoading && <li>Loading...</li>}
                {!isLoading && (
                  <li>
                    {myInfo.body.name} ({myInfo.body.email})
                  </li>
                )}
              </>
            )}
          </ul>
        </nav>
      </header>
      <LoginMemberModal setToken={setToken} ref={loginModalRef} />
      <RegistMemberModal ref={registModalRef} />
    </>
  );
}
