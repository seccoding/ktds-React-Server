import { forwardRef } from "react";

export const Input = forwardRef(({ id, title, error, ...props }, ref) => {
  return (
    <>
      <label htmlFor={id}>{title}</label>
      <input id={id} {...props} ref={ref} />
      {error && <div>{error}</div>}
    </>
  );
});

export const Textarea = forwardRef(({ id, title, ...props }, ref) => {
  return (
    <>
      <label htmlFor={id}>{title}</label>
      <textarea id={id} {...props} ref={ref}></textarea>
    </>
  );
});

export function Button({ children, ...props }) {
  return <button {...props}>{children}</button>;
}

export function ButtonArea({ children }) {
  return <div className="button-area right-align">{children}</div>;
}
