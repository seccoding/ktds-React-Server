export default function Table({ children }) {
  return <table>{children}</table>;
}

Table.Colgroup = ({ cols }) => {
  return (
    <colgroup>
      {cols.map((col, index) => (
        <col key={index} width={col} />
      ))}
    </colgroup>
  );
};

Table.Header = ({ children }) => {
  return <thead>{children}</thead>;
};

Table.Body = ({ children }) => {
  return <tbody>{children}</tbody>;
};
