import { forwardRef, useRef } from "react";
import { Button, ButtonArea, Input, Textarea } from "../ui/Input.js";
import { Modal } from "./Modal.js";
import { writeArticle } from "../../http/http.js";

export const WriteModal = forwardRef(({ token, needReloadList }, ref) => {
  const subjectRef = useRef();
  const fileRef = useRef();
  const contentRef = useRef();

  const onClickRegistHandler = () => {
    const subject = subjectRef.current.value;
    const content = contentRef.current.value;

    subjectRef.current.value = "";
    contentRef.current.value = "";

    writeArticle(token, {
      subject,
      content,
      file: fileRef.current.files[0],
    })
      .then((response) => {
        if (response.body) {
          needReloadList(Math.random());
          ref.current.close();
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const onClickCancelHandler = () => {
    subjectRef.current.value = "";
    contentRef.current.value = "";
    ref.current.close();
  };

  return (
    <Modal ref={ref}>
      <h3>게시글 등록</h3>
      <div>
        <Input
          id="write-subject"
          title="Subject"
          placeholder="Subject"
          type="text"
          ref={subjectRef}
        />
        <Input
          id="write-file"
          title="File"
          placeholder="File"
          type="file"
          ref={fileRef}
        />
        <Textarea id="write-content" title="Content" ref={contentRef} />
        <ButtonArea>
          <Button onClick={onClickRegistHandler}>등록</Button>
          <Button onClick={onClickCancelHandler}>취소</Button>
        </ButtonArea>
      </div>
    </Modal>
  );
});
