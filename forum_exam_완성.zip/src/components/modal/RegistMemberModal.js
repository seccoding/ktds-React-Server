import { forwardRef, useRef, useState } from "react";
import { Button, ButtonArea, Input } from "../ui/Input.js";
import { Modal } from "./Modal.js";
import { regist } from "../../http/http.js";

export const RegistMemberModal = forwardRef((props, ref) => {
  const emailRef = useRef();
  const nameRef = useRef();
  const passwordRef = useRef();
  const passwordConfirmRef = useRef();

  const [emailError, setEmailError] = useState();
  const [nameError, setNameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [passwordConfirmError, setPasswordConfirmError] = useState();

  const [registError, setRegistError] = useState();

  const onClickRegistHandler = () => {
    console.log(emailRef.current);
    const email = emailRef.current.value;
    const name = nameRef.current.value;
    const password = passwordRef.current.value;
    const passwordConfirm = passwordConfirmRef.current.value;

    let hasError = false;

    setEmailError("");
    setNameError("");
    setPasswordError("");
    setPasswordConfirmError("");

    if (!email) {
      setEmailError("이메일을 입력해주세요.");
      hasError = true;
    }
    if (!name) {
      setNameError("이름을 입력해주세요.");
      hasError = true;
    }
    if (!password) {
      setPasswordError("비밀번호를 입력해주세요.");
      hasError = true;
    }
    if (!passwordConfirm || password !== passwordConfirm) {
      setPasswordConfirmError("비밀번호가 일치하지 않습니다. 입력해주세요.");
      hasError = true;
    }

    if (!hasError) {
      regist(email, name, password)
        .then((response) => {
          console.log(response);
          if (response.errors) {
            setRegistError(response.errors.message);
          } else {
            ref.current.close();
          }
        })
        .catch((error) => {
          console.log(error);
          setRegistError(error.message);
        });
    }
  };

  const onClickCancelHandler = () => {
    setEmailError("");
    setNameError("");
    setPasswordError("");
    setPasswordConfirmError("");

    ref.current.close();
  };

  return (
    <Modal ref={ref}>
      <h3>회원 등록</h3>
      {registError && <div>{registError}</div>}
      <div>
        <Input
          id="regit-email"
          title="Email"
          type="email"
          ref={emailRef}
          error={emailError}
        />
        <Input
          id="regist-name"
          title="Name"
          type="text"
          ref={nameRef}
          error={nameError}
        />
        <Input
          id="regist-password"
          title="Password"
          type="password"
          ref={passwordRef}
          error={passwordError}
        />
        <Input
          id="regist-password-confirm"
          title="Password"
          type="password"
          ref={passwordConfirmRef}
          error={passwordConfirmError}
        />
        <ButtonArea>
          <Button onClick={onClickRegistHandler}>등록</Button>
          <Button onClick={onClickCancelHandler}>취소</Button>
        </ButtonArea>
      </div>
    </Modal>
  );
});
