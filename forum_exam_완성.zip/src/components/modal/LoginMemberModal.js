import { forwardRef, useRef, useState } from "react";
import { Button, ButtonArea, Input } from "../ui/Input.js";
import { Modal } from "./Modal.js";
import { getToken } from "../../http/http.js";

export const LoginMemberModal = forwardRef(({ setToken }, ref) => {
  const emailRef = useRef();
  const passwordRef = useRef();

  const [emailError, setEmailError] = useState();
  const [passwordError, setPasswordError] = useState();

  const [loginError, setLoginError] = useState();

  const onClickRegistHandler = () => {
    setEmailError("");
    setPasswordError("");
    setLoginError("");

    const email = emailRef.current.value;
    const password = passwordRef.current.value;

    let hasError = false;

    if (!email) {
      setEmailError("이메일을 입력해주세요.");
      hasError = true;
    }

    if (!password) {
      setPasswordError("비밀번호를 입력해주세요.");
      hasError = true;
    }

    if (!hasError) {
      getToken(email, password)
        .then((response) => {
          if (response.message) {
            setLoginError(response.message);
          } else {
            sessionStorage.setItem("token", response.token);
            setToken(response.token);
            ref.current.close();
          }
        })
        .catch((error) => {
          console.log("Err", error.message);
          setLoginError(error.message);
        });
    }
  };

  const onClickCancelHandler = () => {
    ref.current.close();
  };

  return (
    <Modal ref={ref}>
      <h3>로그인</h3>
      {loginError && <div>{loginError}</div>}
      <div>
        <Input
          id="login-email"
          title="Email"
          type="email"
          ref={emailRef}
          error={emailError}
        />
        <Input
          id="login-password"
          title="Password"
          type="password"
          ref={passwordRef}
          error={passwordError}
        />
        <ButtonArea>
          <Button onClick={onClickRegistHandler}>등록</Button>
          <Button onClick={onClickCancelHandler}>취소</Button>
        </ButtonArea>
      </div>
    </Modal>
  );
});
