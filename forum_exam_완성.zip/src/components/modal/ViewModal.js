import { forwardRef, useCallback, useMemo, useRef, useState } from "react";
import { Button, ButtonArea, Input, Textarea } from "../ui/Input.js";
import { Modal } from "./Modal.js";
import { useFetch } from "../../hooks/useFetch.js";
import {
  deleteArticle,
  loadArticleById,
  modifyArticle,
} from "../../http/http.js";

export const ViewModal = forwardRef(
  ({ token, selectedId, needReloadList }, ref) => {
    const subjectRef = useRef();
    const fileRef = useRef();
    const contentRef = useRef();

    const errorModalRef = useRef();

    const [modifyMode, setModifyMode] = useState(false);
    const [needReload, setNeedReload] = useState();

    const [errorMessage, setErrorMessage] = useState();

    console.log(selectedId, "번 조회함.");

    const cachedInitialValue = useMemo(() => {
      return {
        body: {},
      };
    }, []);
    const cachedLoadArticle = useCallback(
      () => loadArticleById(token, selectedId),
      [token, selectedId, needReload]
    );
    const {
      fetchedResult: { body: article },
      isLoading,
      error,
    } = useFetch(cachedInitialValue, cachedLoadArticle);

    const onClickModifyHandler = () => {
      setModifyMode(true);
    };

    const onClickCancelHandler = () => {
      setModifyMode(false);
    };

    const onClickSaveHandler = () => {
      modifyArticle(token, {
        id: selectedId,
        subject: subjectRef.current.value,
        content: contentRef.current.value,
        file: fileRef.current.files[0],
      })
        .then((response) => {
          if (!response.errors) {
            setModifyMode(false);
            setNeedReload(Math.random());
            needReloadList(Math.random());
          } else {
            setErrorMessage(response.errors.message);
            errorModalRef.current.open();
          }
        })
        .catch((error) => {
          console.log(error.message);
          setErrorMessage(error.message);
          errorModalRef.current.open();
        });
    };

    const onClickDeleteHandler = () => {
      deleteArticle(token, selectedId)
        .then((response) => {
          if (!response.errors) {
            needReloadList(Math.random());
            ref.current.close();
          } else {
            setErrorMessage(response.errors.message);
            errorModalRef.current.open();
          }
        })
        .catch((error) => {
          console.log(error.message);
          setErrorMessage(error.message);
          errorModalRef.current.open();
        });
    };

    const onCloseModalHandler = () => {
      setModifyMode(false);
    };

    return (
      <>
        <Modal onClose={onCloseModalHandler} ref={ref}>
          <h3>게시글 조회</h3>
          <div>
            {modifyMode && (
              <>
                <Input
                  id="modify-subject"
                  title="Subject"
                  placeholder="Subject"
                  type="text"
                  ref={subjectRef}
                  defaultValue={article.subject}
                />
                <Input
                  id="modify-file"
                  title="File"
                  placeholder="File"
                  type="file"
                  ref={fileRef}
                />
                <Textarea
                  id="modify-content"
                  title="Content"
                  ref={contentRef}
                  defaultValue={article.content}
                />
                <ButtonArea>
                  <Button onClick={onClickSaveHandler}>저장</Button>
                  <Button onClick={onClickCancelHandler}>취소</Button>
                </ButtonArea>
              </>
            )}

            {!modifyMode && (
              <>
                <div>{!isLoading && !error && article.subject}</div>
                <div>{!isLoading && !error && article.memberVO.name}</div>
                <div>{!isLoading && !error && article.content}</div>
                <ButtonArea>
                  <Button onClick={onClickModifyHandler}>수정</Button>
                  <Button onClick={onClickDeleteHandler}>삭제</Button>
                </ButtonArea>
              </>
            )}
          </div>
        </Modal>
        <Modal ref={errorModalRef}>
          <div>{errorMessage}</div>
        </Modal>
      </>
    );
  }
);
