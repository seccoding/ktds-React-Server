import { useEffect, useState } from "react";
import Header from "./components/Header";
import Main from "./components/Main";

export default function App() {
  const [token, setToken] = useState();
  useEffect(() => {
    setToken(sessionStorage.getItem("token"));
  }, []);
  return (
    <div className="main-container">
      <Header token={token} setToken={setToken} />
      <Main token={token} />
    </div>
  );
}
