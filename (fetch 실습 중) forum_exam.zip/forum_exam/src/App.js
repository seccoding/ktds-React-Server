import { useCallback } from "react";
import Header from "./components/Header";
import Main from "./components/Main";
import { useFetch } from "./hooks/useFetch";
import { checkEmail } from "./http/http";

export default function App() {
  const cachedCheckEmail = useCallback(() => {
    return checkEmail("test@mail.com");
  }, []);

  const { fetchedResult, isLoading, error } = useFetch(
    undefined,
    cachedCheckEmail
  );

  console.log(fetchedResult, isLoading, error);

  return (
    <div className="main-container">
      <Header />
      <Main />
    </div>
  );
}
