const HOST = "http://localhost:8888";

/**
 * 이메일 중복 검사 Fetch
 */
export async function checkEmail(email) {
  // Fetch요청 보내기
  const response = await fetch(`${HOST}/api/v1/member/available/${email}/`, {
    method: "GET",
  });

  console.log("response", response);

  // 요청 성공했을 때, 응답 데이터 반환.
  if (response.ok) {
    // 요청의 응답 받아오기
    const json = await response.json();
    return json;
  }

  // 요청 실패했을 때, 실패 데이터를 예외에 담아서 반환.
  throw new Error(response.statusText);
}

/**
 * 회원가입
 */
export async function regist(email, name, password) {}

/**
 * 로그인 토큰 발급
 */
export async function getToken(email, password) {}
