import { useRef } from "react";
import { LoginMemberModal } from "./modal/LoginMemberModal.js";
import { RegistMemberModal } from "./modal/RegistMemberModal.js";

export default function Header() {
  const loginModalRef = useRef();
  const registModalRef = useRef();

  const onClickLoginHandler = () => {
    loginModalRef.current.open();
  };

  const onClickRegistHandler = () => {
    registModalRef.current.open();
  };

  return (
    <>
      <header>
        <nav>
          <ul>
            <li onClick={onClickLoginHandler}>Login</li>
            <li onClick={onClickRegistHandler}>Regist</li>
            <li>Logout</li>
          </ul>
        </nav>
      </header>
      <LoginMemberModal ref={loginModalRef} />
      <RegistMemberModal ref={registModalRef} />
    </>
  );
}
