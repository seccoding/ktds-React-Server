import { forwardRef, useImperativeHandle, useRef } from "react";
import { createPortal } from "react-dom";

export const Modal = forwardRef(({ children, onClose = () => {} }, ref) => {
  const modalRef = useRef();

  useImperativeHandle(ref, () => {
    return {
      open() {
        modalRef.current.showModal();
      },
      close() {
        modalRef.current.close();
      },
    };
  });

  const onClickCloseHandler = () => {
    onClose();
    modalRef.current.close();
  };

  return createPortal(
    <dialog onClose={onClickCloseHandler} className="modal" ref={modalRef}>
      <div className="modal-body">
        <section className="modal-close-button" onClick={onClickCloseHandler}>
          X
        </section>
        {children}
      </div>
    </dialog>,
    document.querySelector("#modals")
  );
});
