export const SAMPLE_DATA = [
  {
    id: 1,
    subject: "Subject1",
    email: "testemail@email.com",
    viewCnt: 1,
    crtDt: "2024-04-01",
    memberVO: {
      name: "testuser",
    },
  },
  {
    id: 2,
    subject: "Subject2",
    email: "testemail2@email.com",
    viewCnt: 10,
    crtDt: "2024-03-01",
    memberVO: {
      name: "testuser2",
    },
  },
];
