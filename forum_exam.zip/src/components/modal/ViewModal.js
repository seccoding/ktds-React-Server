import { forwardRef, useRef, useState } from "react";
import { Button, ButtonArea, Input, Textarea } from "../ui/Input.js";
import { Modal } from "./Modal.js";

export const ViewModal = forwardRef(({ selectedId }, ref) => {
  const subjectRef = useRef();
  const fileRef = useRef();
  const contentRef = useRef();

  const [modifyMode, setModifyMode] = useState(false);

  console.log(selectedId, "번 조회함.");

  const onClickModifyHandler = () => {
    setModifyMode(true);
  };

  const onClickCancelHandler = () => {
    setModifyMode(false);
  };

  const onClickSaveHandler = () => {
    setModifyMode(false);
  };

  const onClickDeleteHandler = () => {
    ref.current.close();
  };

  const onCloseModalHandler = () => {
    setModifyMode(false);
  };

  return (
    <Modal onClose={onCloseModalHandler} ref={ref}>
      <h3>게시글 조회</h3>
      <div>
        {modifyMode && (
          <>
            <Input
              id="modify-subject"
              title="Subject"
              placeholder="Subject"
              type="text"
              ref={subjectRef}
            />
            <Input
              id="modify-file"
              title="File"
              placeholder="File"
              type="file"
              ref={fileRef}
            />
            <Textarea id="modify-content" title="Content" ref={contentRef} />
            <ButtonArea>
              <Button onClick={onClickSaveHandler}>저장</Button>
              <Button onClick={onClickCancelHandler}>취소</Button>
            </ButtonArea>
          </>
        )}

        {!modifyMode && (
          <>
            <div>제목</div>
            <div>작성자</div>
            <div>내용</div>
            <ButtonArea>
              <Button onClick={onClickModifyHandler}>수정</Button>
              <Button onClick={onClickDeleteHandler}>삭제</Button>
            </ButtonArea>
          </>
        )}
      </div>
    </Modal>
  );
});
