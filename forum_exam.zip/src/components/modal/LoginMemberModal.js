import { forwardRef, useRef } from "react";
import { Button, ButtonArea, Input } from "../ui/Input.js";
import { Modal } from "./Modal.js";

export const LoginMemberModal = forwardRef((props, ref) => {
  const emailRef = useRef();
  const passwordRef = useRef();

  const onClickRegistHandler = () => {
    ref.current.close();
  };

  const onClickCancelHandler = () => {
    ref.current.close();
  };

  return (
    <Modal ref={ref}>
      <h3>회원 등록</h3>
      <div>
        <Input id="login-email" title="Email" type="email" ref={emailRef} />
        <Input
          id="login-password"
          title="Password"
          type="password"
          ref={passwordRef}
        />
        <ButtonArea>
          <Button onClick={onClickRegistHandler}>등록</Button>
          <Button onClick={onClickCancelHandler}>취소</Button>
        </ButtonArea>
      </div>
    </Modal>
  );
});
