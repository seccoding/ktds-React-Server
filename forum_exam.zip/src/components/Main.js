import { useRef, useState } from "react";
import { SAMPLE_DATA } from "../sampledata/sampledata.js";
import { Button, ButtonArea } from "./ui/Input.js";
import Table from "./ui/Table.js";
import { WriteModal } from "./modal/WriteModal.js";
import { ViewModal } from "./modal/ViewModal.js";
export default function Main() {
  const [datas, setDatas] = useState(SAMPLE_DATA);
  const [selectedItemId, setSelectedItemId] = useState();

  const writeRef = useRef();
  const viewRef = useRef();

  const onClickWriteHandler = () => {
    writeRef.current.open();
  };

  const onClickViewHandler = (id) => {
    setSelectedItemId(id);
    viewRef.current.open();
  };

  return (
    <main>
      <div className="right-align">
        총 {SAMPLE_DATA.length}건의 게시글이 조회되었습니다.
      </div>
      <Table>
        <Table.Colgroup cols={["80px", "*", "150px", "80px", "150px"]} />
        <Table.Header>
          <tr>
            <th>ID</th>
            <th>Subject</th>
            <th>Author</th>
            <th>View</th>
            <th>Create Date</th>
          </tr>
        </Table.Header>
        <Table.Body>
          {datas.map(
            ({ id, subject, email, viewCnt, crtDt, memberVO: { name } }) => (
              <tr
                key={`${id}_${subject}`}
                onClick={() => onClickViewHandler(id)}
              >
                <td>{id}</td>
                <td>{subject}</td>
                <td title={email}>{name}</td>
                <td>{viewCnt}</td>
                <td>{crtDt}</td>
              </tr>
            )
          )}
        </Table.Body>
      </Table>
      <ButtonArea>
        <Button>더보기</Button>
        <Button onClick={onClickWriteHandler}>등록</Button>
      </ButtonArea>

      <WriteModal ref={writeRef} setDatas={setDatas} />
      <ViewModal ref={viewRef} selectedId={selectedItemId} />
    </main>
  );
}
