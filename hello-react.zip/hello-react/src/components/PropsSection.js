export default function PropsSection({
  title,
  color,
  backgroundColor,
  onMouseOver,
  onMouseClick,
  children, // <-- 컴포넌트 사이에 작성된 컴포넌트 혹은 태그의 묶음이 배열로 전달.
}) {
  // React CSS 정의하는 방법 ==> { }
  const styles = { color, backgroundColor };

  return (
    <div onClick={onMouseClick} onMouseOver={onMouseOver} style={styles}>
      {title && `This is ${title} Component`}
      {children}
    </div>
  );
}
