import { forwardRef, useImperativeHandle, useRef } from "react";
import { createPortal } from "react-dom";

// 2024년 4월에 발표된 React의 ref props (18.3.1 버전)
export default function AlertModal({ children, modalRef }) {
  return (
    <dialog className="modal" ref={modalRef}>
      <div className="modal-body">
        <section className="modal-close-button">X</section>
        {children}
      </div>
    </dialog>
  );
}

// 2024년 4월 이전까지의 ref를 props로 보내는 방법.
export const AlertModalOldVersion = forwardRef(({ children }, ref) => {
  const modalRef = useRef();

  // ref.current 에게 객체 또는 함수를 할당하는 역할.
  useImperativeHandle(ref, () => {
    return {
      open() {
        modalRef.current.showModal();
      },
      close() {
        modalRef.current.close();
      },
    };
  });

  return (
    <>
      {createPortal(
        <dialog className="modal" ref={modalRef}>
          <div className="modal-body">
            <section className="modal-close-button">X</section>
            {children}
          </div>
        </dialog>,
        document.querySelector("#modals")
      )}
    </>
  );
});
