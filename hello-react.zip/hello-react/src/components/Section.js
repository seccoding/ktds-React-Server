export default function Section() {
  return <div>This is Section Component</div>;
}
