import { useEffect, useState } from "react";

export const useFetch = (initialValue, fnFetch, objParam = {}) => {
  const [fetchedData, setFetchedData] = useState(initialValue);
  const [error, setError] = useState();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetching() {
      setIsLoading(true);
      try {
        const fetchResult = await fnFetch({ ...objParam });
        setFetchedData(fetchResult);
      } catch (e) {
        setError(e.message || "데이터를 불러오지 못했습니다.");
      } finally {
        setIsLoading(false);
      }
    }
    fetching();
  }, [fnFetch, objParam]);

  return { fetchedData, setFetchedData, error, isLoading };
};
