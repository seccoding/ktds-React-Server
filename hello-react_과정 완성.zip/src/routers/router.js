import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Main from "../components/main/Main";
import TodoApp from "../components/todo/TodoApp";
import ToolkitProvider from "../stores/toolkit/store";
import MainLayout from "../layout/MainLayout";
import NotFound from "../layout/NotFound";
import SubTodo from "../components/todo/SubTodo";

export default function RouterAppProvider() {
  const routers = createBrowserRouter([
    {
      path: "/",
      element: <MainLayout />,
      errorElement: <NotFound />,
      children: [
        { index: true, element: <Main /> }, // "/" URL의 대표 컴포넌트
        {
          path: "todo/",
          element: <ToolkitProvider />,
          children: [
            {
              index: true, // "/todo" URL의 대표 컴포넌트
              element: <TodoApp />,
            },
            {
              path: ":id",
              element: <SubTodo />,
            },
          ],
        },
      ],
    },
  ]);

  return <RouterProvider router={routers} />;
}
