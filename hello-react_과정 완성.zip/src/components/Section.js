export default function Section({ title, color, backgroundColor, fontSize }) {
  const sectionCss = {
    backgroundColor: backgroundColor,
    color: color,
    fontSize: fontSize,
  };

  return <div style={sectionCss}>This is a {title} Compoenent</div>;
}
