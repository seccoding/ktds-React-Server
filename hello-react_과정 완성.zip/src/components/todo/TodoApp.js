import Todo from "./Todo";
import AddTodo from "./AddTodo";
import { useCallback, useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTodo, loadTodo } from "../../stores/toolkit/store";

export default function TodoApp() {
  const styles = {
    backgroundColor: "#FFF",
    margin: "0 auto",
    marginTop: "1rem",
    width: "50rem",
  };

  const flexStyle = useMemo(() => {
    return {
      display: "flex",
      padding: "0.5rem",
      marginTop: "1rem",
    };
  }, []);

  const todo = useSelector((state) => {
    return state.todo;
  });

  const todoDispatch = useDispatch();
  const addTodoHandler = useCallback(
    (task, dueDate) => {
      const payload = {
        id: parseInt(Math.random() * 100_000_000),
        isDone: false,
        task,
        dueDate,
      };
      todoDispatch(addTodo(payload));
    },
    [todoDispatch]
  );

  useEffect(() => {
    todoDispatch(loadTodo());
  }, [todoDispatch]);

  console.log(todo);
  return (
    <div style={styles}>
      <h4 style={{ padding: "1rem" }}>
        완료: {todo.filter((item) => item.isDone).length} / 미완료:{" "}
        {todo.filter((item) => !item.isDone).length}
      </h4>
      <ul>
        {todo.map((todo) => (
          <Todo key={todo.id} todo={todo} style={flexStyle} />
        ))}
      </ul>
      <AddTodo onAdd={addTodoHandler} style={flexStyle} />
    </div>
  );
}
