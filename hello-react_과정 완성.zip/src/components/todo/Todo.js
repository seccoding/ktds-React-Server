import { useDispatch } from "react-redux";
import { done, subDone } from "../../stores/toolkit/store";
import { Link } from "react-router-dom";

export default function Todo({ todo, style, parentTodoId }) {
  console.log("Run Todo");

  const { id, isDone, task, dueDate } = todo;

  const styles = {
    ...style,
    marginTop: 0,
    borderBottom: "1px solid #ccc",
    padding: "1rem",
    color: isDone ? "#ccc" : "#333",
    textDecoration: isDone ? "line-through" : "none",
  };

  const todoDispatch = useDispatch();
  const onChange = (event) => {
    const checkbox = event.currentTarget;
    const todoId = parseInt(checkbox.value);

    // React Redux에 상태 변경을 요청한다.
    const doneItem = { id: todoId, isDone: checkbox.checked, task, dueDate };

    if (parentTodoId) {
      doneItem.parentTodoId = parseInt(parentTodoId);
      todoDispatch(subDone(doneItem));
    } else {
      todoDispatch(done(doneItem));
    }
  };

  return (
    <li style={styles}>
      <div style={{ marginRight: "1rem" }}>
        <input
          key={id}
          defaultValue={id}
          type="checkbox"
          checked={isDone ? "checked" : ""}
          onChange={onChange}
        />
      </div>
      <div style={{ flexGrow: 1 }}>
        {!parentTodoId && <Link to={`/todo/${id}`}>{task}</Link>}
        {parentTodoId && task}
      </div>
      <div>{dueDate}</div>
    </li>
  );
}
