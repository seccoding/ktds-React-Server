import { useMemo } from "react";
import AddTodo from "./AddTodo";
import Todo from "./Todo";
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addSubTodo } from "../../stores/toolkit/store";

export default function SubTodo() {
  const param = useParams();
  const navigate = useNavigate();

  const styles = {
    backgroundColor: "#FFF",
    margin: "0 auto",
    marginTop: "1rem",
    width: "50rem",
  };

  const flexStyle = useMemo(() => {
    return {
      display: "flex",
      padding: "0.5rem",
      marginTop: "1rem",
    };
  }, []);

  const { todo, subTodo } = useSelector((state) => {
    const mapToArray = (subTodoMap) => {
      const subArray = [];
      for (let key in subTodoMap) {
        subArray.push(subTodoMap[key]);
      }
      return subArray;
    };

    const todo = state.todo.find((item) => item.id === parseInt(param.id));
    const subTodo = mapToArray(todo.sub);
    return { todo, subTodo };
  });

  const subDispatch = useDispatch();
  const addTodoHandler = (task, dueDate) => {
    const payload = {
      parentTodoId: parseInt(param.id),
      id: parseInt(Math.random() * 100_000_000),
      isDone: false,
      task,
      dueDate,
    };

    subDispatch(addSubTodo(payload));
  };

  return (
    <div style={styles}>
      <h3>{todo.task}</h3>
      <h4>Due Date: {todo.dueDate}</h4>
      <h4>{todo.isDone ? "완료된 작업" : "진행중 작업"}</h4>
      <h4 style={{ padding: "1rem" }}>
        완료: {subTodo.filter((item) => item.isDone).length} / 미완료:{" "}
        {subTodo.filter((item) => !item.isDone).length}
      </h4>
      <ul>
        {subTodo.map((todo) => (
          <Todo
            key={todo.id}
            todo={todo}
            style={flexStyle}
            parentTodoId={param.id}
          />
        ))}
      </ul>
      <AddTodo onAdd={addTodoHandler} style={flexStyle} />

      <div onClick={() => navigate("/todo")}>Todo List</div>
    </div>
  );
}
