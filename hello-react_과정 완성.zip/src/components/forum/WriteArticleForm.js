export default function WriteArticleForm() {
  return <></>;
}
