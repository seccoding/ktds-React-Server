import { useEffect, useState } from "react";
import { LoginForm, RegistForm } from "./MemberForm";
import {
  deleteMe,
  getMyInfo,
  loginMember,
  logoutMe,
  registMember,
} from "./http/http";

export default function LogStatus({ token, setToken }) {
  const [myInfo, setMyInfo] = useState();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegistModal, setShowRegistModal] = useState(false);

  const isLoginState = token !== undefined && myInfo !== undefined;

  const onLoginHandler = () => {
    setShowLoginModal(true);
  };

  const onLoginCloseHandler = () => {
    setShowLoginModal(false);
  };

  const onRegistHandler = () => {
    setShowRegistModal(true);
  };

  const onRegistCloseHandler = () => {
    setShowRegistModal(false);
  };

  const registMemberHandler = async (email, name, password) => {
    const json = await registMember(email, name, password);
    if (json.body) {
      loginMemberHandler(email, password);
      setShowRegistModal(false);
    } else {
      alert(json.errors.message);
    }
  };

  const loginMemberHandler = async (email, password) => {
    const jwt = await loginMember(email, password);

    if (jwt.token) {
      setToken(jwt.token);
      setShowLoginModal(false);
    } else {
      alert(jwt.message);
    }
  };

  const logoutMeHandler = async () => {
    const json = await logoutMe(token);
    console.log(json);
    setToken(undefined);
    setMyInfo(undefined);
  };

  const deleteMeHandler = async () => {
    const json = await deleteMe(token);
    console.log(json);

    setToken(undefined);
    setMyInfo(undefined);
  };

  useEffect(() => {
    async function loadInfo() {
      const json = await getMyInfo(token);
      setMyInfo(json.body);
    }
    loadInfo();
  }, [token, setMyInfo]);

  return (
    <>
      <nav>
        <ul>
          {isLoginState && (
            <>
              <li>
                {myInfo.name} ({myInfo.email})
              </li>
              <li>
                <span className="anchor" onClick={logoutMeHandler}>
                  Sign Out
                </span>
              </li>
              <li>
                <span className="anchor" onClick={deleteMeHandler}>
                  Delete My Account
                </span>
              </li>
            </>
          )}
          {!isLoginState && (
            <>
              <li>
                <span className="anchor" onClick={onLoginHandler}>
                  Sign In
                </span>
              </li>
              <li>
                <span className="anchor" onClick={onRegistHandler}>
                  Sign Up
                </span>
              </li>
            </>
          )}
        </ul>
      </nav>

      <LoginForm
        showModal={showLoginModal}
        onClose={onLoginCloseHandler}
        onLogin={loginMemberHandler}
      />
      <RegistForm
        showModal={showRegistModal}
        onClose={onRegistCloseHandler}
        onRegist={registMemberHandler}
      />
    </>
  );
}
