import { useEffect, useRef } from "react";
import Modal from "./ui/Modal";
import { Button, Input } from "./ui/Input";

export function LoginForm({ showModal, onClose, onLogin }) {
  const modal = useRef();
  const email = useRef();
  const password = useRef();

  useEffect(() => {
    if (showModal) {
      modal.current.open();
    } else if (modal) {
      modal.current.close();
    }
  }, [showModal]);

  const onLoginHandler = () => {
    const emailValue = email.current.value;
    const passwordValue = password.current.value;

    if (emailValue === "") {
      alert("Email을 입력하세요");
      email.current.focus();
      return;
    }

    if (passwordValue === "") {
      alert("Password를 입력하세요");
      password.current.focus();
      return;
    }

    onLogin(emailValue, passwordValue);
  };

  return (
    <Modal ref={modal} onClose={onClose}>
      <Input
        id="email"
        title="Email"
        type="email"
        placeholder="Email"
        ref={email}
      />
      <Input
        id="password"
        title="Password"
        type="password"
        placeholder="Password"
        ref={password}
      />
      <Button type="button" onClick={onLoginHandler}>
        Login
      </Button>
    </Modal>
  );
}

export function RegistForm({ showModal, onClose, onRegist }) {
  const modal = useRef();
  const email = useRef();
  const name = useRef();
  const password = useRef();
  const rePassword = useRef();

  useEffect(() => {
    if (showModal) {
      modal.current.open();
    } else if (modal) {
      modal.current.close();
    }
  }, [showModal]);

  const onRegistHandler = () => {
    const emailValue = email.current.value;
    const nameValue = name.current.value;
    const passwordValue = password.current.value;
    const rePasswordValue = rePassword.current.value;

    if (emailValue === "") {
      alert("Email을 입력하세요");
      email.current.focus();
      return;
    }

    if (nameValue === "") {
      alert("Name을 입력하세요");
      name.current.focus();
      return;
    }

    if (passwordValue === "") {
      alert("Password를 입력하세요");
      password.current.focus();
      return;
    }

    if (rePasswordValue === "") {
      alert("Password 확인을 입력하세요");
      rePasswordValue.current.focus();
      return;
    }

    if (passwordValue !== rePasswordValue) {
      alert("Password가 일치하지 않습니다.");
      return;
    }

    onRegist(emailValue, nameValue, passwordValue);
  };

  return (
    <Modal ref={modal} onClose={onClose}>
      <Input
        id="email"
        title="Email"
        type="email"
        placeholder="Email"
        ref={email}
      />
      <Input id="name" title="Name" type="text" placeholder="Name" ref={name} />
      <Input
        id="password"
        title="Password"
        type="password"
        placeholder="Password"
        ref={password}
      />
      <Input
        id="re-password"
        title="Password 확인"
        type="password"
        placeholder="Password 확인"
        ref={rePassword}
      />
      <Button type="button" onClick={onRegistHandler}>
        Regist
      </Button>
    </Modal>
  );
}
