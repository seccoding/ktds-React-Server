import { useRef, forwardRef, useImperativeHandle } from "react";
import { createPortal } from "react-dom";

const Modal = forwardRef(({ children, onClose = () => {} }, ref) => {
  const modal = useRef();

  useImperativeHandle(ref, () => {
    return {
      open() {
        modal.current.showModal();
      },
      close() {
        modal.current.close();
      },
    };
  });

  const closeModal = () => {
    modal.current.close();
    onClose();
  };
  return (
    <>
      {createPortal(
        <dialog className="modal" ref={modal}>
          <div className="modal-body">
            <section className="modal-close-button" onClick={closeModal}>
              X
            </section>
            {children}
          </div>
        </dialog>,
        document.querySelector("#modals")
      )}
    </>
  );
});

export default Modal;
