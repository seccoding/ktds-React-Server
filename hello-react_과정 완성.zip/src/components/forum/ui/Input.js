import { forwardRef } from "react";

export const Input = forwardRef(
  ({ title, id, defaultValue = "", ...props }, ref) => {
    return (
      <div className="input-group">
        <label htmlFor={id}>{title}</label>
        <input {...props} id={id} defaultValue={defaultValue} ref={ref} />
      </div>
    );
  }
);

export function Button({ children, ...props }) {
  return <input type="button" {...props} value={children} />;
}
