import ViewReply from "./ViewReply";
import { Button } from "./ui/Input";

export default function ViewArticle({ token, article }) {
  return (
    <>
      <article>
        <h3>{article.subject}</h3>
        <div>
          {article.memberVO.name} ({article.email})
        </div>
        <div>View: {article.viewCnt}</div>
        <div>{article.content}</div>
      </article>

      <div className="button-area right-align">
        <Button type="button" onClick={() => {}}>
          삭제
        </Button>
      </div>

      <ViewReply token={token} selectedArticleId={article.id} />
    </>
  );
}
