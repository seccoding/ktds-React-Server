export const registMember = async ({ email, name, password }) => {
  const response = await fetch("http://localhost:8888/api/v1/member", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email, name, password }),
  });
  return await response.json();
};

export const loginMember = async ({ email, password }) => {
  const response = await fetch("http://localhost:8888/api/v1/auth/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });
  return await response.json();
};

export const getMyInfo = async ({ token }) => {
  const response = await fetch("http://localhost:8888/api/v1/member", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
    },
  });
  return await response.json();
};

export const logoutMe = async ({ token }) => {
  const response = await fetch("http://localhost:8888/api/v1/member/logout", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
    },
  });
  return await response.json();
};

export const deleteMe = async ({ token }) => {
  const response = await fetch("http://localhost:8888/api/v1/member", {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
    },
  });
  return await response.json();
};

export const loadArticles = async ({ token, pageNo = 0 }) => {
  const response = await fetch(
    `http://localhost:8888/api/v1/boards?pageNo=${pageNo}`,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
    }
  );
  return await response.json();
};

export const loadReplies = async ({ token, boardId }) => {
  const response = await fetch(
    `http://localhost:8888/api/v1/reply/${boardId}`,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
    }
  );
  return await response.json();
};

export const writeReply = async ({ token, boardId, content }) => {
  const response = await fetch(
    `http://localhost:8888/api/v1/reply/${boardId}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
      body: JSON.stringify({ content }),
    }
  );
  return await response.json();
};
