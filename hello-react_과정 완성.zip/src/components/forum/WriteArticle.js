export default function WriteArticle() {
  return <></>;
}
