import { useState } from "react";
import Article from "./Article";
import Header from "./Header";

export default function ArticleApp() {
  const [token, setToken] = useState();

  return (
    <div className="main-container">
      <Header token={token} setToken={setToken} />

      <Article token={token} />
    </div>
  );
}
