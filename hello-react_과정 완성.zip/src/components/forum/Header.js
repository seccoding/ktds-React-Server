import LogStatus from "./LogStatus";

export default function Header({ token, setToken }) {
  return (
    <header>
      <p>Hello-React</p>
      <nav className="menu-navigation">
        <ul>
          <li>Home</li>
          <li>Articles</li>
        </ul>
      </nav>
      <LogStatus token={token} setToken={setToken} />
    </header>
  );
}
