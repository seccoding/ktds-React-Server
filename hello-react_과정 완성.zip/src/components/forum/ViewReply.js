import { useCallback, useEffect, useState } from "react";
import WriteReplyForm from "./WriteReplyForm";
import { loadReplies, writeReply } from "./http/http";

export default function ViewReply({ token, selectedArticleId }) {
  const [replies, setReplies] = useState({});
  const [loadRepliesError, setLoadRepliesError] = useState();
  const [isReplyLoading, setIsReplyLoading] = useState(true);

  const writeReplyHandler = async (content) => {
    await writeReply(token, selectedArticleId, content);
    fetchReplies();
  };

  const fetchReplies = useCallback(async () => {
    setIsReplyLoading(true);
    try {
      const json = await loadReplies(token, selectedArticleId);
      setReplies(json.body);
    } catch (e) {
      setLoadRepliesError("댓글을 불러올 수 없습니다.");
    } finally {
      setIsReplyLoading(false);
    }
  }, [token, selectedArticleId]);

  useEffect(() => {
    fetchReplies();
  }, [token, selectedArticleId, fetchReplies]);

  return (
    <>
      {isReplyLoading && <div>Reply Loading...</div>}
      {!isReplyLoading && loadRepliesError && <div>{loadRepliesError}</div>}
      {!isReplyLoading &&
        replies.map((item) => (
          <article className="reply" key={item.id}>
            <div>
              {item.memberVO.name} ({item.memberVO.email})
            </div>
            <pre>{item.content}</pre>
          </article>
        ))}
      <WriteReplyForm onWrite={writeReplyHandler} />
    </>
  );
}
