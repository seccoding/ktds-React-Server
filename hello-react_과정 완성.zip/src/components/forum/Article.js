import { useCallback, useEffect, useState } from "react";
import { loadArticles } from "./http/http";
import ViewArticle from "./ViewArticle";
import WriteArticle from "./WriteArticle";
import WriteArticleForm from "./WriteArticleForm";

export default function Article({ token }) {
  const [articles, setArticles] = useState({});
  const [loadArticlesError, setLoadArticlesError] = useState();
  const [isArticleLoading, setIsArticleLoading] = useState(true);

  const [selectedArticleId, setSelectedArticleId] = useState();
  const [writeMode, setWriteMode] = useState(false);

  const writeModeHandler = () => {
    setWriteMode((prevMode) => !prevMode);
  };

  const writeArticleHandler = async (subject, content, file) => {
    const response = await fetch();
    const json = await response.json();
    fetchArticles();
  };

  const selectArticleHandler = (selectedArticleId) => {
    setSelectedArticleId(selectedArticleId);
  };

  const fetchArticles = useCallback(async () => {
    setIsArticleLoading(true);
    try {
      const json = await loadArticles(token);
      setArticles(json);
    } catch (e) {
      setLoadArticlesError("게시글을 불러올 수 없습니다.");
    } finally {
      setIsArticleLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchArticles();
  }, [token, fetchArticles]);

  return (
    <>
      {selectedArticleId && (
        <>
          <ViewArticle
            token={token}
            article={articles.body.find(
              (item) => item.id === selectedArticleId
            )}
          />
        </>
      )}

      {!isArticleLoading && loadArticlesError && <div>{loadArticlesError}</div>}
      {isArticleLoading && <div>Article Loading...</div>}
      {!isArticleLoading && (
        <table>
          <colgroup>
            <col width="80" />
            <col width="*" />
            <col width="250" />
            <col width="80" />
          </colgroup>
          <thead>
            <tr>
              <th>번호</th>
              <th>제목</th>
              <th>작성자</th>
              <th>조회수</th>
            </tr>
          </thead>
          <tbody>
            {articles.body &&
              articles.body.map((item) => (
                <tr key={item.id} onClick={() => selectArticleHandler(item.id)}>
                  <td>{item.id}</td>
                  <td>{item.subject}</td>
                  <td>
                    {item.memberVO.name} ({item.email})
                  </td>
                  <td>{item.viewCnt}</td>
                </tr>
              ))}
          </tbody>
        </table>
      )}

      {!writeMode && <WriteArticle onChangeMode={writeModeHandler} />}
      {writeMode && (
        <WriteArticleForm
          onChangeMode={writeModeHandler}
          onWrite={writeArticleHandler}
        />
      )}
    </>
  );
}
