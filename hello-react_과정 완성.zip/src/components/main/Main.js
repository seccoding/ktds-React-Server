export default function Main() {
  return <section>Welcome to React world!</section>;
}
