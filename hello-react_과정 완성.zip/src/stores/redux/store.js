import { Provider } from "react-redux";
import { createStore } from "redux";

/**
 * Redux Reducer
 * @param state React Redux가 관리하는 State
 * @param action React Redux State를 변경할 Dispatcher의 Action Param
 * @returns
 */
function reduxReducer(
  state = {
    todo: [],
    article: [],
  },
  action
) {
  const target = action.target;
  const type = action.type;
  const payload = action.payload;

  // TODO Reducer
  if (target === "todo") {
    // TODO 추가
    if (type === "ADD-TODO") {
      return {
        article: [...state.article],
        todo: [
          ...state.todo,
          {
            id: state.todo.length,
            isDone: false,
            task: payload.task,
            dueDate: payload.dueDate,
          },
        ],
      };
    }
    // TODO 완료/미완료 토글 처리
    else if (type === "DONE") {
      return {
        article: [...state.article],
        todo: state.todo.map((item) => {
          if (item.id === payload.id) {
            item.isDone = payload.isDone;
          }
          return item;
        }),
      };
    }
  }

  return state;
}

/**
 * Redux Store 생성
 * Redux Store는 Redux Reducer로 관리한다.
 * @returns Redux Store
 */
function store() {
  return createStore(reduxReducer);
}

/**
 * React Context처럼 Redux도 Provider가 필요하다.
 */
export default function ReduxProvider({ children }) {
  const reduxStore = store();
  return <Provider store={reduxStore}>{children}</Provider>;
}
