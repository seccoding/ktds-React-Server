import { configureStore, createSlice } from "@reduxjs/toolkit";
import { Provider } from "react-redux";
import { Outlet } from "react-router-dom";

/**
 * Todo만을 위한 Slice Store
 */
const todoSliceStore = createSlice({
  name: "todo store", // Slice Store를 구분할 구분 값.
  initialState: [], // Slice Store의 초기값
  reducers: {
    // 데이터 다운로드
    load(state, action) {
      if (state.length === 0) {
        state.push(...action.payload);
      }
    },
    // Reducer들은 함수로 관리한다.
    add(state, action) {
      const payload = action.payload;
      state.push({
        id: payload.id,
        isDone: payload.isDone,
        task: payload.task,
        dueDate: payload.dueDate,
        sub: {},
      });
    },
    done(state, action) {
      const payload = action.payload;
      const selectTodoId = payload.id;
      const index = state.findIndex((item) => item.id === selectTodoId);
      state[index].isDone = payload.isDone;
    },
    addSub(state, action) {
      const payload = action.payload;
      const parentTodoId = payload.parentTodoId;
      const index = state.findIndex((item) => item.id === parentTodoId);

      if (!state[index].sub) {
        state[index].sub = {};
      }

      state[index].sub[payload.id] = {
        id: payload.id,
        isDone: payload.isDone,
        task: payload.task,
        dueDate: payload.dueDate,
        parentTodoId: payload.parentTodoId,
      };
    },
    doneSub(state, action) {
      const payload = action.payload;
      const parentTodoId = payload.parentTodoId;
      const doneSubTodoId = payload.id;
      const index = state.findIndex((item) => item.id === parentTodoId);

      state[index].sub[doneSubTodoId].isDone = payload.isDone;
    },
  },
});

/**
 * Redux Toolkit Store
 * Slice Store들이 여기에 저장된다.
 */
const store = configureStore({
  reducer: {
    // slice_store에_접근할_이름: 슬라이스_스토어_리듀서_모음
    todo: todoSliceStore.reducer,
  },
});

//Thunks Start
export const loadTodo = () => {
  return async (dispatch) => {
    const url = "https://react-todo-91655-default-rtdb.firebaseio.com";

    const sendRequest = async () => {
      const response = await fetch(`${url}/todo.json`, {
        method: "GET",
      });
      const json = await response.json();
      const todoList = [];

      for (let key in json) {
        todoList.push(json[key]);
      }

      dispatch(todoActions.load(todoList));
    };

    sendRequest();
  };
};

export const addTodo = (todoItem) => {
  return async (dispatch) => {
    const url = "https://react-todo-91655-default-rtdb.firebaseio.com";

    dispatch(todoActions.add(todoItem));

    const sendRequest = async () => {
      await fetch(`${url}/todo/${todoItem.id}.json`, {
        method: "PUT",
        body: JSON.stringify(todoItem),
      });
    };

    sendRequest();
  };
};

export const done = (todoItem) => {
  return async (dispatch) => {
    const url = "https://react-todo-91655-default-rtdb.firebaseio.com/";

    dispatch(todoActions.done(todoItem));

    const sendRequest = async () => {
      await fetch(`${url}/todo/${todoItem.id}.json`, {
        method: "PUT",
        body: JSON.stringify(todoItem),
      });
    };

    sendRequest();
  };
};

export const addSubTodo = (todoItem) => {
  return async (dispatch) => {
    const url = "https://react-todo-91655-default-rtdb.firebaseio.com/";

    dispatch(todoActions.addSub(todoItem));

    const sendRequest = async () => {
      await fetch(
        `${url}/todo/${todoItem.parentTodoId}/sub/${todoItem.id}.json`,
        {
          method: "PUT",
          body: JSON.stringify(todoItem),
        }
      );
    };

    sendRequest();
  };
};

export const subDone = (todoItem) => {
  return async (dispatch) => {
    const url = "https://react-todo-91655-default-rtdb.firebaseio.com/";

    dispatch(todoActions.doneSub(todoItem));

    const sendRequest = async () => {
      await fetch(
        `${url}/todo/${todoItem.parentTodoId}/sub/${todoItem.id}.json`,
        {
          method: "PUT",
          body: JSON.stringify(todoItem),
        }
      );
    };

    sendRequest();
  };
};
//Thunks End

/**
 * todo slice의 action 객체를 노출
 */
export const todoActions = todoSliceStore.actions;

export default function ToolkitProvider() {
  return (
    <Provider store={store}>
      <Outlet />
    </Provider>
  );
}
