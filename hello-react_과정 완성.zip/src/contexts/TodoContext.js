import { createContext, useReducer } from "react";

const TodoContext = createContext({
  todo: [],
  done: (event) => {},
  add: (task, dueDate) => {},
});

export default TodoContext;

/**
 * State를 관리하는 함수들만 별도로 분리해 보관하는 리듀서
 * @param state 리듀서가 관리할 스테이트
 * @param action 스테이트를 변경할 정보들
 */
const todoReducers = (state, action) => {
  const type = action.type;
  if (type === "ADD") {
    return [
      ...state,
      {
        id: state.length,
        idDone: false,
        task: action.payload.task,
        dueDate: action.payload.dueDate,
      },
    ];
  } else if (type === "DONE") {
    const id = action.payload.id;
    return state.map((item) => {
      if (item.id === id) {
        item.isDone = action.payload.isDone;
      }
      return item;
    });
  }

  return state;
};

export function TodoContextProvider({ children }) {
  /*
   * useReducer Hook을 이용해 State를 관리한다.
   * todoState: reducer가 관리할 State
   * todoDispatcher: Reducer에게 State 변경을 요청하는 함수
   *           todoReducers() 함수를 호출하게 된다.
   */
  const [todoState, todoDispatcher] = useReducer(todoReducers, []);

  const contextValue = {
    todo: todoState,
    done: (event) => {
      const checkbox = event.currentTarget;
      const id = parseInt(checkbox.value);
      todoDispatcher({
        type: "DONE",
        payload: { id, isDone: checkbox.checked },
      });
    },
    add: (task, dueDate) => {
      todoDispatcher({ type: "ADD", payload: { task, dueDate } });
    },
  };

  return (
    <TodoContext.Provider value={contextValue}>{children}</TodoContext.Provider>
  );
}
