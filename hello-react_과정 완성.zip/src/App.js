import RouterAppProvider from "./routers/router";

function App() {
  return <RouterAppProvider />;
}

export default App;
