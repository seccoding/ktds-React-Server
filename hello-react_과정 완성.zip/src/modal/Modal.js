import { useRef, forwardRef, useImperativeHandle } from "react";

const AlertModal = forwardRef(({ children }, ref) => {
  const modal = useRef();

  useImperativeHandle(ref, () => {
    return {
      open() {
        modal.current.showModal();
      },
      close() {
        modal.current.close();
      },
    };
  });

  const closeModal = () => {
    modal.current.close();
  };
  return (
    <dialog className="modal" ref={modal}>
      <div className="modal-body">
        <section className="modal-close-button" onClick={closeModal}>
          X
        </section>
        {children}
      </div>
    </dialog>
  );
});

export default AlertModal;
